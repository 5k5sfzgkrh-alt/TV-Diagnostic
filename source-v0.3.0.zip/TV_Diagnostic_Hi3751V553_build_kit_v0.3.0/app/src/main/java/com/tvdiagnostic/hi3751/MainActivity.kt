package com.tvdiagnostic.hi3751

import android.app.Activity
import android.app.ActivityManager
import android.content.pm.PackageManager
import android.os.Process
import android.content.Context
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class MainActivity : Activity() {
    private lateinit var reportView: TextView
    private lateinit var statusView: TextView
    private var gpuInfo = "GPU: данные OpenGL ещё не получены"
    private val executor = Executors.newSingleThreadExecutor()
    private var lastReport = JSONObject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        collectGpuInfo()
        refreshReport()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 22)
            setBackgroundColor(0xFF101820.toInt())
        }
        val title = TextView(this).apply {
            text = "TV DIAGNOSTIC  •  Hi3751V553  •  0.2.0"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
        }
        statusView = TextView(this).apply {
            text = "Инициализация диагностики…"
            textSize = 15f
            setTextColor(0xFF80CBC4.toInt())
            setPadding(0, 8, 0, 14)
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val refresh = makeButton("Обновить") { refreshReport() }
        val root = makeButton("Проверить Root") { checkRoot() }
        val export = makeButton("Экспорт JSON") { exportReport() }
        buttons.addView(refresh)
        buttons.addView(root)
        buttons.addView(export)
        reportView = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFE8EEF2.toInt())
            setLineSpacing(5f, 1.0f)
            setPadding(0, 16, 0, 24)
            isFocusable = true
        }
        val scroll = ScrollView(this).apply { addView(reportView) }
        outer.addView(title)
        outer.addView(statusView)
        outer.addView(buttons)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
        refresh.requestFocus()
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isFocusable = true
            textSize = 13f
            setOnClickListener { action() }
        }

    private fun collectGpuInfo() {
        val glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        glView.setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                val vendor = gl?.glGetString(GL10.GL_VENDOR) ?: "неизвестно"
                val renderer = gl?.glGetString(GL10.GL_RENDERER) ?: "неизвестно"
                val version = gl?.glGetString(GL10.GL_VERSION) ?: "неизвестно"
                runOnUiThread {
                    gpuInfo = "GPU Vendor: $vendor\nGPU Renderer: $renderer\nOpenGL ES: $version"
                    if (::reportView.isInitialized) refreshReport()
                }
            }
            override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {}
            override fun onDrawFrame(gl: GL10?) {}
        })
        addContentView(glView, android.widget.FrameLayout.LayoutParams(1, 1, Gravity.TOP or Gravity.START))
    }

    private fun refreshReport() {
        statusView.text = "Сбор показателей CPU, RAM, температуры и ZRAM…"
        executor.execute {
            val report = collectBasicReport()
            lastReport = report
            runOnUiThread {
                reportView.text = formatReport(report)
                statusView.text = "Обычный режим • только чтение • без изменений системы"
            }
        }
    }

    private fun collectBasicReport(): JSONObject {
        val j = JSONObject()
        j.put("timestamp", System.currentTimeMillis())
        j.put("manufacturer", Build.MANUFACTURER)
        j.put("brand", Build.BRAND)
        j.put("model", Build.MODEL)
        j.put("device", Build.DEVICE)
        j.put("board", Build.BOARD)
        j.put("product", Build.PRODUCT)
        j.put("android", Build.VERSION.RELEASE)
        j.put("sdk", Build.VERSION.SDK_INT)
        j.put("fingerprint", Build.FINGERPRINT)
        j.put("kernel", readText("/proc/version"))
        j.put("cpuinfo", readText("/proc/cpuinfo", 12000))
        j.put("meminfo", readText("/proc/meminfo", 6000))
        j.put("swaps", readText("/proc/swaps", 3000))
        j.put("uptime", readText("/proc/uptime", 1000))
        j.put("gpu", gpuInfo)

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        j.put("ramTotalBytes", mi.totalMem)
        j.put("ramAvailableBytes", mi.availMem)
        j.put("lowMemory", mi.lowMemory)

        val stat = StatFs(Environment.getDataDirectory().absolutePath)
        j.put("dataTotalBytes", stat.totalBytes)
        j.put("dataAvailableBytes", stat.availableBytes)
        j.put("display", "${resources.displayMetrics.widthPixels}x${resources.displayMetrics.heightPixels}")
        j.put("densityDpi", resources.displayMetrics.densityDpi)

        j.put("cpuFrequencies", collectCpuFrequencies())
        j.put("cpuGovernor", collectCpuGovernor())
        j.put("cpuLoadPercent", collectCpuLoad())
        j.put("temperatures", collectTemperatures())
        j.put("zram", collectZram())
        j.put("runningProcesses", collectRunningProcesses())
        j.put("installedPackages", collectInstalledPackages())
        j.put("rootStatus", "not_checked")
        return j
    }

    private fun collectCpuFrequencies(): JSONArray {
        val result = JSONArray()
        for (i in 0..7) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = readNumber(base + "scaling_cur_freq")
            val min = readNumber(base + "scaling_min_freq")
            val max = readNumber(base + "scaling_max_freq")
            if (cur != null || min != null || max != null) {
                result.put(JSONObject().apply {
                    put("cpu", i)
                    put("currentKHz", cur ?: JSONObject.NULL)
                    put("minKHz", min ?: JSONObject.NULL)
                    put("maxKHz", max ?: JSONObject.NULL)
                })
            }
        }
        return result
    }

    private fun collectCpuGovernor(): String {
        val candidates = listOf(
            "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor",
            "/sys/devices/system/cpu/cpufreq/policy0/scaling_governor"
        )
        return candidates.firstNotNullOfOrNull { readTextOrNull(it)?.trim() } ?: "недоступно"
    }

    private fun collectCpuLoad(): String {
        return try {
            val first = readCpuCounters() ?: return "недоступно"
            Thread.sleep(350)
            val second = readCpuCounters() ?: return "недоступно"
            val total = second.first - first.first
            val idle = second.second - first.second
            if (total <= 0) "недоступно"
            else String.format(Locale.US, "%.1f%%", 100.0 * (total - idle).toDouble() / total)
        } catch (_: Exception) {
            "недоступно"
        }
    }

    private fun readCpuCounters(): Pair<Long, Long>? {
        val line = readText("/proc/stat", 2000).lineSequence().firstOrNull { it.startsWith("cpu ") } ?: return null
        val v = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (v.size < 4) return null
        val total = v.sum()
        val idle = v[3] + (v.getOrNull(4) ?: 0L)
        return total to idle
    }

    private fun collectTemperatures(): JSONArray {
        val result = JSONArray()
        val dir = File("/sys/class/thermal")
        val zones = dir.listFiles { f -> f.name.startsWith("thermal_zone") } ?: return result
        zones.sortedBy { it.name }.forEach { zone ->
            val raw = readNumber("${zone.absolutePath}/temp")
            val type = readTextOrNull("${zone.absolutePath}/type")?.trim() ?: "unknown"
            if (raw != null) {
                val celsius = if (raw > 1000) raw / 1000.0 else raw.toDouble()
                result.put(JSONObject().apply {
                    put("zone", zone.name)
                    put("type", type)
                    put("celsius", celsius)
                })
            }
        }
        return result
    }

    private fun collectZram(): JSONObject {
        val z = JSONObject()
        val candidates = listOf("/sys/block/zram0", "/sys/block/zram1")
        val found = candidates.firstOrNull { File(it).exists() }
        if (found == null) {
            z.put("status", "не обнаружен или недоступен")
            return z
        }
        z.put("device", found)
        z.put("disksizeBytes", readNumber("$found/disksize") ?: JSONObject.NULL)
        z.put("mmStat", readTextOrNull("$found/mm_stat") ?: "недоступно")
        z.put("ioStat", readTextOrNull("$found/io_stat") ?: "недоступно")
        z.put("status", "обнаружен")
        return z
    }


    private fun collectRunningProcesses(): JSONArray {
        val result = JSONArray()
        return try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val processes = am.runningAppProcesses ?: return result
            for (proc in processes.sortedBy { it.importance }.take(60)) {
                val item = JSONObject()
                item.put("processName", proc.processName ?: "unknown")
                item.put("pid", proc.pid)
                item.put("uid", proc.uid)
                item.put("importance", proc.importance)
                item.put("importanceLabel", importanceLabel(proc.importance))
                try {
                    val mem = am.getProcessMemoryInfo(intArrayOf(proc.pid)).firstOrNull()
                    if (mem != null) {
                        item.put("pssKb", mem.totalPss)
                        item.put("privateDirtyKb", mem.totalPrivateDirty)
                    }
                } catch (_: Exception) {
                    item.put("memoryInfo", "недоступно")
                }
                result.put(item)
            }
            result
        } catch (_: Exception) {
            result.put(JSONObject().put("error", "список процессов недоступен"))
            result
        }
    }

    private fun importanceLabel(value: Int): String = when (value) {
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND -> "foreground"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE -> "foreground_service"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE -> "visible"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_PERCEPTIBLE -> "perceptible"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE -> "service"
        ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED -> "cached"
        else -> "other($value)"
    }

    @Suppress("DEPRECATION")
    private fun collectInstalledPackages(): JSONArray {
        val result = JSONArray()
        return try {
            val pm = packageManager
            val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA)
            for (pkg in packages.sortedBy { it.packageName }.take(500)) {
                val appInfo = pkg.applicationInfo ?: continue
                val item = JSONObject()
                item.put("packageName", pkg.packageName)
                item.put("appName", try { pm.getApplicationLabel(appInfo).toString() } catch (_: Exception) { pkg.packageName })
                item.put("systemApp", (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0)
                item.put("updatedSystemApp", (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0)
                item.put("enabled", appInfo.enabled)
                item.put("versionName", pkg.versionName ?: "")
                item.put("targetSdk", appInfo.targetSdkVersion)
                item.put("firstInstallTime", pkg.firstInstallTime)
                item.put("lastUpdateTime", pkg.lastUpdateTime)
                result.put(item)
            }
            result
        } catch (e: Exception) {
            result.put(JSONObject().put("error", e.message ?: "список пакетов недоступен"))
            result
        }
    }

    private fun checkRoot() {
        statusView.text = "Проверка root… Команда только читает идентификатор пользователя."
        executor.execute {
            val result = runRootProbe()
            lastReport.put("rootStatus", result.first)
            lastReport.put("rootOutput", result.second)
            runOnUiThread {
                statusView.text = "Проверка Root: ${result.first}"
                reportView.text = formatReport(lastReport)
            }
        }
    }

    private fun runRootProbe(): Pair<String, String> {
        return try {
            val process = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
            val finished = process.waitForWithTimeout(5000)
            if (!finished) {
                process.destroyForcibly()
                "timeout" to "su не завершился за 5 секунд; процесс остановлен"
            } else {
                val output = process.inputStream.bufferedReader().use { it.readText().take(2000) }
                if (process.exitValue() == 0 && output.contains("uid=0")) {
                    "root_confirmed" to output.trim()
                } else {
                    "not_confirmed" to output.trim().ifBlank { "su не предоставил uid=0" }
                }
            }
        } catch (e: Exception) {
            "not_available" to (e.message ?: e.javaClass.simpleName)
        }
    }

    private fun exportReport() {
        val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(android.content.Intent.EXTRA_TITLE, "tv-diagnostic-report-v020.json")
        }
        startActivityForResult(intent, 4102)
    }

    @Deprecated("Deprecated by platform; retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4102 && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.use {
                    it.write(lastReport.toString(2).toByteArray(Charsets.UTF_8))
                }
                statusView.text = "JSON-отчёт сохранён."
            } catch (e: Exception) {
                statusView.text = "Ошибка экспорта: ${e.message}"
            }
        }
    }

    private fun formatReport(j: JSONObject): String {
        fun mb(key: String) = String.format(Locale.US, "%.0f МБ", j.optLong(key) / 1048576.0)
        return buildString {
            appendLine("УСТРОЙСТВО")
            appendLine("${j.optString("manufacturer")} / ${j.optString("model")}")
            appendLine("Board: ${j.optString("board")}   Device: ${j.optString("device")}")
            appendLine("Product: ${j.optString("product")}")
            appendLine("Android: ${j.optString("android")} (API ${j.optInt("sdk")})")
            appendLine()
            appendLine("CPU")
            appendLine("Загрузка за короткий интервал: ${j.optString("cpuLoadPercent")}")
            appendLine("Governor: ${j.optString("cpuGovernor")}")
            val freqs = j.optJSONArray("cpuFrequencies") ?: JSONArray()
            if (freqs.length() == 0) appendLine("Частоты ядер: недоступны")
            for (i in 0 until freqs.length()) {
                val c = freqs.optJSONObject(i) ?: continue
                appendLine("CPU${c.optInt("cpu")}: ${formatMHz(c, "currentKHz")} МГц (min ${formatMHz(c, "minKHz")}, max ${formatMHz(c, "maxKHz")})")
            }
            appendLine()
            appendLine("GPU")
            appendLine(j.optString("gpu"))
            appendLine()
            appendLine("ПАМЯТЬ")
            appendLine("RAM всего: ${mb("ramTotalBytes")}")
            appendLine("RAM доступно: ${mb("ramAvailableBytes")}")
            appendLine("Low memory: ${j.optBoolean("lowMemory")}")
            appendLine("Раздел data: ${mb("dataAvailableBytes")} свободно из ${mb("dataTotalBytes")}")
            appendLine("Swap: ${j.optString("swaps").trim()}")
            val z = j.optJSONObject("zram") ?: JSONObject()
            appendLine("ZRAM: ${z.optString("status", "нет данных")} ${z.optString("device")}")
            if (z.has("disksizeBytes") && !z.isNull("disksizeBytes")) appendLine("ZRAM размер: ${formatBytes(z.optLong("disksizeBytes"))}")
            appendLine("ZRAM mm_stat: ${z.optString("mmStat", "нет данных")}")
            appendLine()
            appendLine("ТЕМПЕРАТУРА")
            val temps = j.optJSONArray("temperatures") ?: JSONArray()
            if (temps.length() == 0) appendLine("Датчики не обнаружены или закрыты для приложений")
            for (i in 0 until temps.length()) {
                val t = temps.optJSONObject(i) ?: continue
                appendLine("${t.optString("zone")} (${t.optString("type")}): ${String.format(Locale.US, "%.1f°C", t.optDouble("celsius"))}")
            }
            appendLine()
            appendLine("ЗАПУЩЕННЫЕ ПРОЦЕССЫ")
            val processes = j.optJSONArray("runningProcesses") ?: JSONArray()
            appendLine("Найдено: ${processes.length()} (показаны доступные приложению)")
            for (i in 0 until minOf(processes.length(), 25)) {
                val proc = processes.optJSONObject(i) ?: continue
                val pss = if (proc.has("pssKb")) " • ${proc.optInt("pssKb")} КБ PSS" else ""
                appendLine("${proc.optString("processName")} [PID ${proc.optInt("pid")}] ${proc.optString("importanceLabel")}$pss")
            }
            appendLine()
            appendLine("УСТАНОВЛЕННЫЕ ПРИЛОЖЕНИЯ")
            val packages = j.optJSONArray("installedPackages") ?: JSONArray()
            appendLine("Пакетов найдено: ${packages.length()}")
            for (i in 0 until minOf(packages.length(), 80)) {
                val pkg = packages.optJSONObject(i) ?: continue
                val kind = if (pkg.optBoolean("systemApp")) "системное" else "пользовательское"
                val enabled = if (pkg.optBoolean("enabled")) "включено" else "отключено"
                appendLine("${pkg.optString("appName")} • ${pkg.optString("packageName")} • $kind • $enabled")
            }
            appendLine()
            appendLine("ЭКРАН")
            appendLine("${j.optString("display")} • ${j.optInt("densityDpi")} dpi")
            appendLine()
            appendLine("ROOT")
            appendLine("Статус: ${j.optString("rootStatus")}")
            if (j.has("rootOutput")) appendLine("Ответ: ${j.optString("rootOutput")}")
            appendLine()
            appendLine("ЯДРО")
            appendLine(j.optString("kernel").take(220))
            appendLine()
            appendLine("Примечание: недоступные sysfs/procfs параметры не означают отсутствие функции — прошивка может закрывать доступ.")
        }
    }

    private fun formatMHz(j: JSONObject, key: String): String {
        if (j.isNull(key)) return "?"
        return String.format(Locale.US, "%.0f", j.optDouble(key) / 1000.0)
    }

    private fun formatBytes(bytes: Long): String =
        String.format(Locale.US, "%.0f МБ", bytes / 1048576.0)

    private fun readNumber(path: String): Long? =
        readTextOrNull(path)?.trim()?.toLongOrNull()

    private fun readTextOrNull(path: String): String? =
        try { File(path).takeIf { it.canRead() }?.readText()?.take(8000) } catch (_: Exception) { null }

    private fun readText(path: String, max: Int = 8000): String =
        readTextOrNull(path)?.take(max) ?: "недоступно"

    private fun Process.waitForWithTimeout(timeoutMs: Long): Boolean {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            try { exitValue(); return true } catch (_: IllegalThreadStateException) {}
            Thread.sleep(100)
        }
        return false
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }
}
